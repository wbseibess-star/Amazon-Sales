
const productList = document.getElementById('product-list');
const form = document.getElementById('product-form');
const sections = document.querySelectorAll('.section');

function showSection(id) {
  sections.forEach(sec => sec.classList.remove('active'));
  document.getElementById(id).classList.add('active');
}

let products = JSON.parse(localStorage.getItem('products')) || [];
renderProducts();

form.addEventListener('submit', (e) => {
  e.preventDefault();
  const name = document.getElementById('name').value;
  const code = document.getElementById('code').value;
  const link = document.getElementById('link').value;
  const image = document.getElementById('image').value;

  products.push({ name, code, link, image });
  localStorage.setItem('products', JSON.stringify(products));
  renderProducts();
  form.reset();
  alert('Producto agregado!');
});

function renderProducts() {
  productList.innerHTML = '';
  products.forEach((p) => {
    const card = document.createElement('div');
    card.className = 'product-card';
    card.innerHTML = `
      <img src="${p.image}" alt="${p.name}" />
      <h2>${p.name}</h2>
      <div class="discount">Código: ${p.code}</div>
      <a href="${p.link}" class="buy-link" target="_blank">Ver en Amazon</a>
    `;
    productList.appendChild(card);
  });
}
