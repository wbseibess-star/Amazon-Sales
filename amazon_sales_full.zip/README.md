
# 🛒 Amazon Sales

![Logo](logo.png)

**Amazon Sales** es una página web diseñada para mostrar productos de Amazon con códigos de descuento exclusivos.

## 🚀 Características
- Interfaz moderna y sencilla
- Panel de administración básico para agregar productos sin tocar el código
- Compatible con GitHub Pages y Netlify

## 📂 Estructura del proyecto
- `index.html` → Página principal
- `style.css` → Estilos de la página
- `script.js` → Lógica de interacción y panel de administración
- `logo.png` → Logo del sitio

## 📌 Cómo usar
1. Sube los archivos a tu repositorio de GitHub.
2. Activa GitHub Pages desde la pestaña **Settings > Pages**.
3. Tu sitio estará disponible en una URL como:  
   `https://TU-USUARIO.github.io/amazon-sales/`

## 💻 Autor
Creado por Wendy con ayuda de ChatGPT.
